function ModeratorPage() {
  return <h2>Moderator Dashboard - Moderate Content</h2>;
}
export default ModeratorPage;
